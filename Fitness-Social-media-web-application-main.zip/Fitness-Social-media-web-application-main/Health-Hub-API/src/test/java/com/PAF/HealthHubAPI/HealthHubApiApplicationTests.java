package com.PAF.HealthHubAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthHubApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
